﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class LoginPage : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btn_login_Click(object sender, EventArgs e)
    {
        int id =Convert.ToInt32(txt_studentid.Text);
        string password = txt_password.Text;
        StudentsDAL dal = new StudentsDAL();
        bool status = dal.LoginStudent(id, password);
            if(status)
        {
            Session["loginid"] = id;
            Response.Redirect("~/Home.aspx");

        }
        else
        {
            lbl_invalid.Text = "invalid user id and password";
        }
       
        
           
        





    }

    protected void btn_NewStudent_Click(object sender, EventArgs e)
    {

    }
}