﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

/// <summary>
/// Summary description for BooksDAL
/// </summary>
public class BooksDAL
{
    SqlConnection con = new SqlConnection
         ((ConfigurationManager.ConnectionStrings["constr"].ConnectionString));


    public int addbooks(Books obj)
    {
        try
        {
            SqlCommand com_add = new SqlCommand("proc_AddBook", con);
            com_add.Parameters.AddWithValue("@bname", obj.BookName);
            com_add.Parameters.AddWithValue("@aname", obj.AuthorName);
            com_add.Parameters.AddWithValue("@image", obj.BookImage);


            com_add.CommandType = CommandType.StoredProcedure;
            SqlParameter retdata = new SqlParameter();
            retdata.Direction = ParameterDirection.ReturnValue;
            com_add.Parameters.Add(retdata);

            con.Open();
            com_add.ExecuteNonQuery();
            con.Close();
            int id = Convert.ToInt32(retdata.Value);
            return id;

        }
        finally
        {
            if (con.State == ConnectionState.Open) { con.Close(); }
        }

    }

    public List<Books> Searchbook(string key)
    {
        try
        {
            List<Books> list_books = new List<Books>();
            SqlCommand com_books = new SqlCommand("proc_Searchbook", con);
            com_books.Parameters.AddWithValue("@key", key);
            com_books.CommandType = CommandType.StoredProcedure;
            con.Open();
            SqlDataReader dr = com_books.ExecuteReader();

            while (dr.Read())
            {
                Books b = new Books();
                b.BookID = dr.GetInt32(0);
                b.BookName = dr.GetString(1);
                b.AuthorName = dr.GetString(2);
                b.BookImage = dr.GetString(3);
                list_books.Add(b);

            }

            return list_books;

        }
        finally
        {
            if (con.State == ConnectionState.Open) { con.Close(); }

        }
    }


    public Books Find(int ID)
    {
        try
        {
            SqlCommand com_books = new SqlCommand("proc_Details", con);
            com_books.Parameters.AddWithValue("@bid", ID);
            com_books.CommandType = CommandType.StoredProcedure;
            con.Open();
            SqlDataReader dr = com_books.ExecuteReader();
            if (dr.Read())
            {
                Books b = new Books();
                b.BookID = dr.GetInt32(0);
                b.BookName = dr.GetString(1);
                b.AuthorName = dr.GetString(2);
                b.BookImage = dr.GetString(3);
                con.Close();
                return b;

            }
            return null;
        }
        finally
        {
            if (con.State == ConnectionState.Open) { con.Close(); }

        }

    }





}






