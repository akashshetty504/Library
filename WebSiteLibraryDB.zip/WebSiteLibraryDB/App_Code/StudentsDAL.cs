﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

/// <summary>
/// Summary description for StudentsDAL
/// </summary>
public class StudentsDAL
{
    SqlConnection con = new SqlConnection
         ((ConfigurationManager.ConnectionStrings["constr"].ConnectionString));

    public int AddStudent(Students obj)
    {
        try
        {
            SqlCommand com_add = new SqlCommand("proc_addstudents", con);
            com_add.Parameters.AddWithValue("@name", obj.StudentName);
            com_add.Parameters.AddWithValue("@emailid", obj.StudentEmailID);
            com_add.Parameters.AddWithValue("@password", obj.StudentPassword);
            com_add.Parameters.AddWithValue("@stdimage", obj.StudentImage);

            com_add.CommandType = CommandType.StoredProcedure;
            SqlParameter retdata = new SqlParameter();
            retdata.Direction = ParameterDirection.ReturnValue;

            com_add.Parameters.Add(retdata);

            con.Open();
            com_add.ExecuteNonQuery();
            con.Close();

            int id = Convert.ToInt32(retdata.Value);
            return id;
        }
        finally
        {
            if(con.State==ConnectionState.Open)
            {
                con.Close();

            }
        }
        
         }

    public bool LoginStudent(int ID, string Password)
    {
        SqlCommand com_login = new SqlCommand("proc_login", con);
        com_login.Parameters.AddWithValue("@sid", ID);
        com_login.Parameters.AddWithValue("@password", Password);

        com_login.CommandType = CommandType.StoredProcedure;
        SqlParameter retdata = new SqlParameter();
        retdata.Direction = ParameterDirection.ReturnValue;

        com_login.Parameters.Add(retdata);
        con.Open();
        com_login.ExecuteNonQuery();


        
        int count = Convert.ToInt32(retdata.Value);
        con.Close();
        if(count>0)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
}