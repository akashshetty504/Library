﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

/// <summary>
/// Summary description for MyIssuedBookDAL
/// </summary>
public class MyIssuedBookDAL
{
    SqlConnection con = new SqlConnection
         ((ConfigurationManager.ConnectionStrings["constr"].ConnectionString));

    public List<MyIssuedBook> myissuebooks(int id)
    {
        SqlCommand com_my_list = new SqlCommand("proc_Myissuebook", con);
        com_my_list.Parameters.AddWithValue("@sid", id);
        com_my_list.CommandType = CommandType.StoredProcedure;
        con.Open();
        SqlDataReader rd = com_my_list.ExecuteReader();
        List<MyIssuedBook> list = new List<MyIssuedBook>();
        while (rd.Read())
        {
            MyIssuedBook m = new MyIssuedBook();
            m.BookID = rd.GetInt32(0);
            m.IssueID = rd.GetInt32(1);
            m.StudentID = rd.GetInt32(2);
            m.IssueDate = rd.GetDateTime(3);
            m.IssueStatus = rd.GetString(4);
            m.BookName = rd.GetString(5);
            m.BookImage = rd.GetString(6);
            list.Add(m);
        }
        return list;

    }

    public int addIssueBook(MyIssuedBook i)
    {
        try
        {


            SqlCommand com_is_insert = new SqlCommand("proc_IssueBook", con);
            com_is_insert.Parameters.AddWithValue("@bid", i.BookID);
            com_is_insert.Parameters.AddWithValue("@sid", i.StudentID);
            com_is_insert.CommandType = CommandType.StoredProcedure;

            SqlParameter retdata = new SqlParameter();
            retdata.Direction = ParameterDirection.ReturnValue;
            com_is_insert.Parameters.Add(retdata);
            con.Open();
            com_is_insert.ExecuteNonQuery();
            int ID = Convert.ToInt32(retdata.Value);
            con.Close();
            return ID;

        }
        finally
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
        }
    }

}