﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;


/// <summary>
/// Summary description for issueDAL
/// </summary>
public class issueDAL
{
    SqlConnection con = new SqlConnection
            ((ConfigurationManager.ConnectionStrings["constr"].ConnectionString));

    public int issuebook(int bid , int sid )
    {
        SqlCommand com_iss = new SqlCommand("proc_IssueBook", con);
        com_iss.Parameters.AddWithValue("@bid", bid);
        com_iss.Parameters.AddWithValue("@sid", sid);
        com_iss.CommandType = CommandType.StoredProcedure;
        SqlParameter retdata = new SqlParameter();
        retdata.Direction = ParameterDirection.ReturnValue;
        com_iss.Parameters.Add(retdata);

        con.Open();
        com_iss.ExecuteNonQuery();
        con.Close();
        int id = Convert.ToInt32(retdata.Value);
        return id;



    }



}