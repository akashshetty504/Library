﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Books
/// </summary>
public class Books
{
    public int BookID { get; set; }
    public string BookName { get; set; }

    public string AuthorName { get; set; }
    public string BookImage { get; set; }

}