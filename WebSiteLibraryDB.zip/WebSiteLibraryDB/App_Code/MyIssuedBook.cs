﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for MyIssuedBook
/// </summary>
public class MyIssuedBook
{
    
    public string BookName { get; set; }
    public int BookID { get; set; }
    public string BookImage { get; set; }

    public int StudentID { get; set; }

    public int IssueID { get; set; }
    public string IssueStatus { get; set; }

    public DateTime IssueDate { get; set; }

}

