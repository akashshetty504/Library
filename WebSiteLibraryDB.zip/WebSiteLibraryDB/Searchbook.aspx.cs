﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Searchbook : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
    }

    protected void btn_Search_Click(object sender, EventArgs e)
    {

        BooksDAL dal = new BooksDAL();
        List<Books> list = new List<Books>();
        list = dal.Searchbook(txt_Search.Text);


        gv.DataSource = list;
        gv.DataBind();

    }

    protected void gv_SelectedIndexChanged(object sender, EventArgs e)
    {
        Label l = gv.SelectedRow.FindControl("lbl_id") as Label;
        string id = l.Text;
        Response.Redirect("~/BookDetails.aspx?id=" + id);

    }
}