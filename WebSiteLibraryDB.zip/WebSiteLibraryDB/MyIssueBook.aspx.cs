﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class MyIssueBook : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
        int id = Convert.ToInt32(Session["loginid"]);
        List<MyIssuedBook> list = new List<MyIssuedBook>();
        MyIssuedBookDAL dal = new MyIssuedBookDAL();
        list = dal.myissuebooks(id);
        gv.DataSource = list;
        gv.DataBind();

    }

    protected void gv_SelectedIndexChanged(object sender, EventArgs e)
    {
        Label l = gv.SelectedRow.FindControl("lbl_bookid") as Label;
        string id = l.Text;

    }
}