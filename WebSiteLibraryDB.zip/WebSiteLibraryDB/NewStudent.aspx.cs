﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class NewStudent : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btn_add_student_Click(object sender, EventArgs e)
    {

        Students obj = new Students();
        obj.StudentName = txt_StudentName.Text;
        obj.StudentEmailID = txt_StudentEmailID.Text;
        obj.StudentPassword = txt_StudentPassword.Text;
        obj.StudentImage = "~/Images/" + Guid.NewGuid() + ".jpg";
        FU_Images.SaveAs(Server.MapPath(obj.StudentImage));
        StudentsDAL dal = new StudentsDAL();
        int id = dal.AddStudent(obj);
        lbl_StudentID.Text = id.ToString();

        
    }
}