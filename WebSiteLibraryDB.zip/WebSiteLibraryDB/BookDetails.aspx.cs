﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class BookDetails : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {
            string id = Request.QueryString["id"];
            int bookid = Convert.ToInt32(id);

            BooksDAL dal = new BooksDAL();
            Books d = dal.Find(bookid);
            lbl_bid.Text = d.BookID.ToString();
            lbl_bname.Text = d.BookName;
            lbl_aname.Text = d.AuthorName;
            img_book.ImageUrl = d.BookImage;
        }
    }

    protected void gv_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    protected void btn_issue_Click(object sender, EventArgs e)
    {
        string id = Request.QueryString["id"];
        int bookid = Convert.ToInt32(id);
        int studentid = Convert.ToInt32(Session["loginid"]);

        issueDAL dal = new issueDAL();
        int issueid = dal.issuebook(bookid,studentid);
        Response.Redirect("~/Default.aspx?id=" + issueid);


    }
}